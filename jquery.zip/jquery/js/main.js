$(document).ready(function () {
    var $form = $('#userForm');
    var $cepInput = $('#cep');
    var $consultarCepButton = $('#consultarCep');

    $form.on('submit', function (event) {
        if (!$form[0].checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        } else {
            $form.addClass('was-validated');

            event.preventDefault();

            $.ajax({
                url: $form.attr('action'),
                type: 'POST',
                data: new FormData($form[0]),
                processData: false,
                contentType: false,
                success: function () {
                    var $successModal = new bootstrap.Modal($('#successModal')[0]);
                    $successModal.show();

                    $('#successModal').on('hidden.bs.modal', function () {
                        window.location.href = 'index.html';
                    });
                }
            });
        }
    });

    $consultarCepButton.on('click', function () {
        var cep = $cepInput.val().replace(/\D/g, ''); 

        if (cep.length === 8) {
            $.ajax({
                url: `https://viacep.com.br/ws/${cep}/json/`,
                type: 'GET',
                success: function (data) {
                    if (!data.erro) {
                        $('#logradouro').val(data.logradouro);
                        $('#bairro').val(data.bairro);
                        $('#cidade').val(data.localidade);
                        $('#estado').val(data.uf);
                    } else {
                        alert('CEP não encontrado');
                        clearAddressFields();
                    }
                },
                error: function () {
                    alert('Erro ao consultar o CEP');
                }
            });
        } else {
            alert('CEP inválido');
            clearAddressFields();
        }
    });

    function clearAddressFields() {
        $('#logradouro').val('');
        $('#bairro').val('');
        $('#cidade').val('');
        $('#estado').val('');
    }
});
