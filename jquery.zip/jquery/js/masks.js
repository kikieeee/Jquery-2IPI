$(document).ready(function () {
    var $telefone = $('#telefone');
    var $cep = $('#cep');
    var $cpf = $('#cpf');
    var $rg = $('#rg');

    // Máscara para telefone
    $telefone.on('input', function () {
        $(this).val(
            $(this).val()
                .replace(/\D/g, '')       
                .replace(/^(\d{2})(\d)/, '($1) $2')
                .replace(/(\d{5})(\d)/, '$1-$2') 
                .replace(/(-\d{4})\d+?$/, '$1')
        );
    });

    // Máscara para CEP
    $cep.on('input', function () {
        $(this).val(
            $(this).val()
                .replace(/\D/g, '')         
                .replace(/^(\d{5})(\d)/, '$1-$2')
                .replace(/(-\d{3})\d+?$/, '$1')
        );
    });

    // Máscara para CPF
    $cpf.on('input', function () {
        $(this).val(
            $(this).val()
                .replace(/\D/g, '')         
                .replace(/^(\d{3})(\d)/, '$1.$2') 
                .replace(/^(\d{3}\.\d{3})(\d)/, '$1.$2') 
                .replace(/^(\d{3}\.\d{3}\.\d{3})(\d)/, '$1-$2')
                .replace(/(-\d{2})\d+?$/, '$1')
        );
    });

    // Máscara para RG
    $rg.on('input', function () {
        $(this).val(
            $(this).val()
                .replace(/\D/g, '')          
                .replace(/^(\d{2})(\d{2})/, '$1.$2') 
                .replace(/^(\d{2}\.\d{3})(\d{2})/, '$1.$2') 
                .replace(/^(\d{2}\.\d{3}\.\d{3})(\d{1,2})/, '$1-$2')
                .slice(0, 12)            
        );
    });

    // Consulta de CEP
    var $consultarCepButton = $('#consultarCep');
    var $cepInput = $('#cep');

    if ($consultarCepButton.length && $cepInput.length) {
        $consultarCepButton.on('click', function () {
            var cep = $cepInput.val().replace(/\D/g, ''); 

            if (cep.length === 8) {
                $.ajax({
                    url: `https://viacep.com.br/ws/${cep}/json/`,
                    type: 'GET',
                    success: function (data) {
                        if (data.erro) {
                            alert('CEP não encontrado.');
                            return;
                        }

                        $('#endereco').val(data.logradouro || '');
                        $('#bairro').val(data.bairro || '');
                        $('#cidade').val(data.localidade || '');
                        $('#estado').val(data.uf || '');
                    },
                    error: function () {
                        alert('Erro ao consultar o CEP.');
                    }
                });
            } else {
                alert('Por favor, insira um CEP válido com 8 dígitos.');
            }
        });
    }
});
