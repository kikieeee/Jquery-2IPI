$(function () {
    let correctCount = 0; // Conta os acertos

    // Salvar o contêiner original para cada forma
    const initialParent = {};

    $(".shape").each(function () {
        const id = $(this).attr("id");
        initialParent[id] = $(this).parent(); // Salva o contêiner pai original
    });

    // Torna as formas arrastáveis
    $(".shape").draggable({
        revert: "invalid"
    });

    // Torna as áreas de destino droppable
    $(".target").droppable({
        accept: function (draggable) {
            // Apenas aceita o elemento se os atributos data-shape forem iguais
            return $(this).data("shape") === $(draggable).data("shape");
        },
        drop: function (event, ui) {
            $(this)
                .addClass("correct")
                .droppable("disable");
            ui.draggable.draggable("disable").css("opacity", "0.5");

            correctCount++; // Incrementa a contagem de acertos

            // Verifica se todas as formas foram posicionadas corretamente
            if (correctCount === 5) {
                alert("Parabéns, você acertou todas as formas, para jogar novamente, clique em reiniciar!");
            }
        }
    });

    // Função para resetar e reorganizar as formas
    function resetShapes() {
        const shapes = $(".shape");

        // Move cada forma de volta ao contêiner original
        shapes.each(function () {
            const id = $(this).attr("id");
            const parent = initialParent[id];
            $(this).appendTo(parent); // Volta ao contêiner original
        });

        // Reorganiza as formas de maneira aleatória
        shapes.sort(() => Math.random() - 0.5).appendTo($(".game-area").first());

        // Reseta estilos e funcionalidades
        shapes.draggable("enable").css({
            opacity: "1",
            position: "relative",
            left: "0",
            top: "0"
        });
        $(".target").removeClass("correct").droppable("enable");

        // Reseta a contagem de acertos
        correctCount = 0;
    }

    // Botão de reiniciar
    $("#reset-button").click(function () {
        resetShapes(); // Reset e reorganização das formas
    });
});
